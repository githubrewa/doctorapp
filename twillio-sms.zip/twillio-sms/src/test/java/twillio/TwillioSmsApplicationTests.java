package twillio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwillioSmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
